// ##################################################################
// # Do NOT edit any of the lines before the "// StartStudentCode"  #
// # line or after the "// EndStudentCode line. Do not remove those #
// # two lines.                                                     #
// #                                                                #
// # If you do edit any of the other code, your submission will     #
// # probably not work.                                             #
// ##################################################################

// StartStudentCode
// EndStudentCode

var assert = require('assert');
describe('Question 2', function() {
    it('test', function() {
        var bmw = new Automobile('BMW', 'Z2', 4);
        assert.equal(bmw.make, 'BMW');
        assert.equal(bmw.model, 'Z2');
        assert.equal(bmw.wheels, 4);
        assert.equal(bmw.summary(), 'BMW Z2 (4 wheels)');
        var ktm = new Automobile('KTM', '1050 Adventure', 2);
        assert.equal(ktm.make, 'KTM');
        assert.equal(ktm.model, '1050 Adventure');
        assert.equal(ktm.wheels, 2);
        assert.equal(ktm.summary(), 'KTM 1050 Adventure (2 wheels)');
    });
});
