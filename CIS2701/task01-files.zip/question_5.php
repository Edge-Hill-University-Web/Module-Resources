<?php
// ##################################################################
// # Do NOT edit any of the lines before the "// StartStudentCode"  #
// # line or after the "// EndStudentCode line. Do not remove those #
// # two lines.                                                     #
// #                                                                #
// # If you do edit any of the other code, your submission will     #
// # probably not work.                                             #
// ##################################################################

class question_5 extends PHPUnit\Framework\TestCase {
    public function test() {
        $random = 14;
        // StartStudentCode

        // EndStudentCode

        //Do not modify 
        $this->assertEquals(4, $remainder);
    }
}

