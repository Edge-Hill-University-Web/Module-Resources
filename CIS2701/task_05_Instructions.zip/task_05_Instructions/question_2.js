// ##################################################################
// # Do NOT edit any of the lines before the "// StartStudentCode"  #
// # line or after the "// EndStudentCode line. Do not remove those #
// # two lines.                                                     #
// #                                                                #
// # If you do edit any of the other code, your submission will     #
// # probably not work.                                             #
// ##################################################################

// StartStudentCode
// EndStudentCode

var assert = require('assert');
describe('Question 2', function() {
    it('test', function() {
        var items = [73, 32, 13, 24, 8, 66];
        var sorted = reverse_merge(items.slice());
        assert.deepEqual(sorted, [73, 66, 32, 24, 13, 8]);
        items = [43, 87, 12];
        sorted = reverse_merge(items.slice());
        assert.deepEqual(sorted, [87, 43, 12]);
    });
});
