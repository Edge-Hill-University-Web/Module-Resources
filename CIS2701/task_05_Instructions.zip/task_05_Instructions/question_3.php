<?php
// ##################################################################
// # Do NOT edit any of the lines before the "// StartStudentCode"  #
// # line or after the "// EndStudentCode line. Do not remove those #
// # two lines.                                                     #
// #                                                                #
// # If you do edit any of the other code, your submission will     #
// # probably not work.                                             #
// ##################################################################

// StartStudentCode
// EndStudentCode

class question_3 extends PHPUnit\Framework\TestCase {
    public function test() {
        $items = ['Mark', 'Dave', 'Tom', 'Robert'];
        $sorted = string_insertion($items);
        $this->assertEquals(['Tom', 'Mark', 'Dave', 'Robert'], $sorted);
        $items = ['aabb', 'aa', 'aba', 'b'];
        $sorted = string_insertion($items);
        $this->assertEquals(['b', 'aa', 'aba', 'aabb'], $sorted);
    }
}

