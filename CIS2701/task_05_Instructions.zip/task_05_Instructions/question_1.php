<?php
// ##################################################################
// # Do NOT edit any of the lines before the "// StartStudentCode"  #
// # line or after the "// EndStudentCode line. Do not remove those #
// # two lines.                                                     #
// #                                                                #
// # If you do edit any of the other code, your submission will     #
// # probably not work.                                             #
// ##################################################################

// StartStudentCode
// EndStudentCode

class question_1 extends PHPUnit\Framework\TestCase {
    public function test() {
        $items = [73, 32, 13, 24, 8, 66];
        $sorted = reverse_insertion($items);
        $this->assertEquals([73, 66, 32, 24, 13, 8], $sorted);
        $items = [43, 87, 12];
        $sorted = reverse_insertion($items);
        $this->assertEquals([87, 43, 12], $sorted);
    }
}

