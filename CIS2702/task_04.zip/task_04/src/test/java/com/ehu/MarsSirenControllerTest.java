package com.ehu;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MarsSirenControllerTest {

    private MarsSirenController ctrl;

    @BeforeEach
    void setup() {
        ctrl = MarsSirenController.getInstance();
        ctrl._resetForTests();
    }

    @Test
    void singletonReturnsSameInstance() {
        MarsSirenController a = MarsSirenController.getInstance();
        MarsSirenController b = MarsSirenController.getInstance();
        assertSame(a, b, "Singleton must always return the same instance");
    }

    @Test
    void armingAndSoundingFlow() {
        assertFalse(ctrl.isArmed());
        assertTrue(ctrl.arm());
        assertTrue(ctrl.isArmed());

        ctrl.setVolume(80);
        assertEquals(80, ctrl.getVolume());

        ctrl.sound();
        assertTrue(ctrl.isSounding());

        ctrl.stop();
        assertFalse(ctrl.isSounding());
    }

    @Test
    void soundWhenNotArmedThrows() {
        assertThrows(IllegalStateException.class, () -> ctrl.sound());
        assertFalse(ctrl.isSounding());
    }

    @Test
    void disarmStopsSiren() {
        ctrl.arm();
        ctrl.sound();
        assertTrue(ctrl.isSounding());

        ctrl.disarm();
        assertFalse(ctrl.isArmed());
        assertFalse(ctrl.isSounding());
    }

    @Test
    void volumeValidation() {
        assertThrows(IllegalArgumentException.class, () -> ctrl.setVolume(-1));
        assertThrows(IllegalArgumentException.class, () -> ctrl.setVolume(101));
        ctrl.setVolume(0);
        ctrl.setVolume(100);
        assertEquals(100, ctrl.getVolume());
    }

    @Test
    void reflectionCannotCreateAnotherInstance() throws Exception {
        MarsSirenController legit = MarsSirenController.getInstance();
        assertNotNull(legit);

        var ctor = MarsSirenController.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        var ex = assertThrows(Exception.class, ctor::newInstance);
        assertTrue(ex.getCause() instanceof IllegalStateException,
                "Reflection should not create a second instance");
    }
}