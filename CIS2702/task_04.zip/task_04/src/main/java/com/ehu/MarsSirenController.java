package com.ehu;

public class MarsSirenController {
    // [ INSERT YOUR CODE BELOW ]





    
    // [ DO NOT DELETE ] This is required and used by unit tests, if it is missing your tests will fail!
    void _resetForTests() {
        armed = false;
        sounding = false;
        volume = 0;
    }
}