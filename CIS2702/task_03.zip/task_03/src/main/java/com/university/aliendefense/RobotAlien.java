package com.university.aliendefense;

/**
 * RobotAlien - A mechanical alien invader.
 * 
 * Robot aliens are powered by batteries. Their defensive shields are powered
 * by their battery, so when the battery is low, they take more damage.
 * 
 * Damage calculation: actualDamage = baseDamage × (batteryPercentage / 100.0)
 */

 // Implement your solution below
public class RobotAlien  {
    
    
}
