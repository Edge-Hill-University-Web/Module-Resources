package com.university.aliendefense;

/**
 * Alien interface representing any extraterrestrial invader.
 * All alien types must implement this interface to be part of the defense system.
 * This interface demonstrates polymorphism - different alien types will implement
 * these methods in their own unique ways.
 */

// Implement your solution below
public interface Alien {

}
