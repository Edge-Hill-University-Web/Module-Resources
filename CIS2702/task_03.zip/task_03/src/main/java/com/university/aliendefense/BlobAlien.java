package com.university.aliendefense;

/**
 * BlobAlien - A gelatinous alien creature.
 * 
 * Blob aliens are squishy creatures whose "gooiness factor" determines
 * how much damage they absorb when attacked. Higher gooiness means
 * the blob spreads the impact across its gelatinous body, taking more damage.
 * 
 * Damage calculation: actualDamage = baseDamage × gooinessFactor
 */

 // Implement your solution below
public class BlobAlien  {

}
