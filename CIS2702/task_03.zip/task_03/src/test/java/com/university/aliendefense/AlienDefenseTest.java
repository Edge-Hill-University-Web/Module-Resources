package com.university.aliendefense;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Comprehensive test suite for the Alien Defense System.
 *
 * This test class verifies all aspects of polymorphism implementation: 1.
 * Interface/Type Checking 2. Method Override Verification 3. Behavioral
 * Differences 4. Dynamic Binding Tests 5. No Type Casting Required 6.
 * Reflection-Based Checks 7. Liskov Substitution Principle
 */
@DisplayName("Alien Defense System - Polymorphism Tests")
public class AlienDefenseTest {

    // ========================================================================
    // 1. INTERFACE/TYPE CHECKING TESTS
    // ========================================================================
    @Nested
    @DisplayName("1. Interface/Type Checking")
    class InterfaceTypeChecking {

        @Test
        @DisplayName("BlobAlien implements Alien interface")
        void blobAlienImplementsInterface() {
            Alien blob = new BlobAlien("Goopy", 100, 1.5);
            assertTrue(blob instanceof Alien,
                    "BlobAlien must implement Alien interface");
        }

        @Test
        @DisplayName("RobotAlien implements Alien interface")
        void robotAlienImplementsInterface() {
            Alien robot = new RobotAlien("Mechanus", 100, 75.0);
            assertTrue(robot instanceof Alien,
                    "RobotAlien must implement Alien interface");
        }

        @Test
        @DisplayName("Can assign BlobAlien to Alien reference")
        void canAssignBlobToAlienReference() {
            assertDoesNotThrow(() -> {
                Alien alien = new BlobAlien("Goo", 50, 1.0);
                assertNotNull(alien);
            }, "Should be able to assign BlobAlien to Alien reference");
        }

        @Test
        @DisplayName("Can assign RobotAlien to Alien reference")
        void canAssignRobotToAlienReference() {
            assertDoesNotThrow(() -> {
                Alien alien = new RobotAlien("Bot", 50, 50.0);
                assertNotNull(alien);
            }, "Should be able to assign RobotAlien to Alien reference");
        }

        @Test
        @DisplayName("Alien interface is actually an interface")
        void alienIsInterface() {
            assertTrue(Alien.class.isInterface(),
                    "Alien must be defined as an interface");
        }
    }

    // ========================================================================
    // 2. METHOD OVERRIDE VERIFICATION
    // ========================================================================
    @Nested
    @DisplayName("2. Method Override Verification")
    class MethodOverrideVerification {

        // ---------------------------
        // Helpers
        // ---------------------------
        private static boolean overridesSupertypeMethod(Class<?> clazz, String name, Class<?>... params) {
            // Must be declared on the subclass (i.e., not merely inherited)
            try {
                clazz.getDeclaredMethod(name, params);
            } catch (NoSuchMethodException e) {
                return false;
            }

            // Check superclass chain
            Class<?> c = clazz.getSuperclass();
            while (c != null) {
                try {
                    c.getMethod(name, params);
                    return true; // a supertype has this method -> overridden
                } catch (NoSuchMethodException ignored) {
                }
                c = c.getSuperclass();
            }
            // Check all interfaces (direct and indirect)
            return declaresOnAnyInterface(clazz, name, params);
        }

        private static boolean declaresOnAnyInterface(Class<?> clazz, String name, Class<?>... params) {
            for (Class<?> iface : clazz.getInterfaces()) {
                try {
                    iface.getMethod(name, params);
                    return true;
                } catch (NoSuchMethodException ignored) {
                }
                // Recurse through interface hierarchy
                if (declaresOnAnyInterface(iface, name, params)) {
                    return true;
                }
            }
            // Also walk up the class hierarchy to inspect their interfaces
            Class<?> sup = clazz.getSuperclass();
            return sup != null && declaresOnAnyInterface(sup, name, params);
        }

        private static void assertRuntimeAnnotationPresent(Method m, Class<? extends Annotation> ann) {
            assertTrue(
                    m.isAnnotationPresent(ann),
                    () -> m.getDeclaringClass().getSimpleName() + "." + m.getName()
                    + " should be annotated with @" + ann.getSimpleName()
            );
        }

        // ---------------------------
        // BlobAlien
        // ---------------------------
        @Test
        @DisplayName("BlobAlien declares takeDamage and overrides a supertype method")
        void blobAlienDeclaresAndOverridesTakeDamage() throws NoSuchMethodException {
            Method method = BlobAlien.class.getDeclaredMethod("takeDamage", int.class);
            assertNotNull(method, "BlobAlien must declare takeDamage(int)");
            assertTrue(Modifier.isPublic(method.getModifiers()), "takeDamage must be public");
            assertTrue(overridesSupertypeMethod(BlobAlien.class, "takeDamage", int.class),
                    "BlobAlien.takeDamage(int) must override a method from a supertype");

        }

        @Test
        @DisplayName("BlobAlien declares isDefeated and overrides a supertype method")
        void blobAlienDeclaresAndOverridesIsDefeated() throws NoSuchMethodException {
            Method method = BlobAlien.class.getDeclaredMethod("isDefeated");
            assertNotNull(method, "BlobAlien must declare isDefeated()");
            assertTrue(Modifier.isPublic(method.getModifiers()), "isDefeated must be public");
            assertTrue(overridesSupertypeMethod(BlobAlien.class, "isDefeated"),
                    "BlobAlien.isDefeated() must override a method from a supertype");

        }

        @Test
        @DisplayName("BlobAlien declares getStatus and overrides a supertype method")
        void blobAlienDeclaresAndOverridesGetStatus() throws NoSuchMethodException {
            Method method = BlobAlien.class.getDeclaredMethod("getStatus");
            assertNotNull(method, "BlobAlien must declare getStatus()");
            assertTrue(Modifier.isPublic(method.getModifiers()), "getStatus must be public");
            assertTrue(overridesSupertypeMethod(BlobAlien.class, "getStatus"),
                    "BlobAlien.getStatus() must override a method from a supertype");
        }

        @Test
        @DisplayName("All interface methods are public in BlobAlien")
        void allMethodsPublicInBlobAlien() {
            Method[] methods = BlobAlien.class.getDeclaredMethods();
            for (Method method : methods) {
                if (method.getName().equals("takeDamage")
                        || method.getName().equals("isDefeated")
                        || method.getName().equals("getStatus")
                        || method.getName().equals("getName")
                        || method.getName().equals("getHealthPoints")) {
                    assertTrue(Modifier.isPublic(method.getModifiers()),
                            "Method " + method.getName() + " must be public");
                }
            }
        }

        // ---------------------------
        // RobotAlien
        // ---------------------------
        @Test
        @DisplayName("RobotAlien declares takeDamage and overrides a supertype method")
        void robotAlienDeclaresAndOverridesTakeDamage() throws NoSuchMethodException {
            Method method = RobotAlien.class.getDeclaredMethod("takeDamage", int.class);
            assertNotNull(method, "RobotAlien must declare takeDamage(int)");
            assertTrue(Modifier.isPublic(method.getModifiers()), "takeDamage must be public");
            assertTrue(overridesSupertypeMethod(RobotAlien.class, "takeDamage", int.class),
                    "RobotAlien.takeDamage(int) must override a method from a supertype");
    
        }

        @Test
        @DisplayName("RobotAlien declares isDefeated and overrides a supertype method")
        void robotAlienDeclaresAndOverridesIsDefeated() throws NoSuchMethodException {
            Method method = RobotAlien.class.getDeclaredMethod("isDefeated");
            assertNotNull(method, "RobotAlien must declare isDefeated()");
            assertTrue(Modifier.isPublic(method.getModifiers()), "isDefeated must be public");
            assertTrue(overridesSupertypeMethod(RobotAlien.class, "isDefeated"),
                    "RobotAlien.isDefeated() must override a method from a supertype");
        }

        @Test
        @DisplayName("RobotAlien declares getStatus and overrides a supertype method")
        void robotAlienDeclaresAndOverridesGetStatus() throws NoSuchMethodException {
            Method method = RobotAlien.class.getDeclaredMethod("getStatus");
            assertNotNull(method, "RobotAlien must declare getStatus()");
            assertTrue(Modifier.isPublic(method.getModifiers()), "getStatus must be public");
            assertTrue(overridesSupertypeMethod(RobotAlien.class, "getStatus"),
                    "RobotAlien.getStatus() must override a method from a supertype");
        }
    }

    // @Nested
    // @DisplayName("2. Method Override Verification")
    // class MethodOverrideVerification {
    //     @Test
    //     @DisplayName("BlobAlien declares takeDamage method")
    //     void blobAlienDeclaresTakeDamage() throws NoSuchMethodException {
    //         Method method = BlobAlien.class.getDeclaredMethod("takeDamage", int.class);
    //         assertNotNull(method, "BlobAlien must declare takeDamage method");
    //     }
    //     @Test
    //     @DisplayName("RobotAlien declares takeDamage method")
    //     void robotAlienDeclaresTakeDamage() throws NoSuchMethodException {
    //         Method method = RobotAlien.class.getDeclaredMethod("takeDamage", int.class);
    //         assertNotNull(method, "RobotAlien must declare takeDamage method");
    //     }
    //     @Test
    //     @DisplayName("BlobAlien declares isDefeated method")
    //     void blobAlienDeclaresIsDefeated() throws NoSuchMethodException {
    //         Method method = BlobAlien.class.getDeclaredMethod("isDefeated");
    //         assertNotNull(method, "BlobAlien must declare isDefeated method");
    //     }
    //     @Test
    //     @DisplayName("RobotAlien declares isDefeated method")
    //     void robotAlienDeclaresIsDefeated() throws NoSuchMethodException {
    //         Method method = RobotAlien.class.getDeclaredMethod("isDefeated");
    //         assertNotNull(method, "RobotAlien must declare isDefeated method");
    //     }
    //     @Test
    //     @DisplayName("BlobAlien declares getStatus method")
    //     void blobAlienDeclaresGetStatus() throws NoSuchMethodException {
    //         Method method = BlobAlien.class.getDeclaredMethod("getStatus");
    //         assertNotNull(method, "BlobAlien must declare getStatus method");
    //     }
    //     @Test
    //     @DisplayName("RobotAlien declares getStatus method")
    //     void robotAlienDeclaresGetStatus() throws NoSuchMethodException {
    //         Method method = RobotAlien.class.getDeclaredMethod("getStatus");
    //         assertNotNull(method, "RobotAlien must declare getStatus method");
    //     }
    //     @Test
    //     @DisplayName("All interface methods are public in BlobAlien")
    //     void allMethodsPublicInBlobAlien() {
    //         Method[] methods = BlobAlien.class.getDeclaredMethods();
    //         for (Method method : methods) {
    //             if (method.getName().equals("takeDamage") || 
    //                 method.getName().equals("isDefeated") ||
    //                 method.getName().equals("getStatus") ||
    //                 method.getName().equals("getName") ||
    //                 method.getName().equals("getHealthPoints")) {
    //                 assertTrue(Modifier.isPublic(method.getModifiers()),
    //                          "Method " + method.getName() + " must be public");
    //             }
    //         }
    //     }
    // }
    // ========================================================================
    // 3. BEHAVIORAL DIFFERENCES TESTS
    // ========================================================================
    @Nested
    @DisplayName("3. Behavioral Differences")
    class BehavioralDifferences {

        @Test
        @DisplayName("Same damage produces different results for different alien types")
        void sameDamageProducesDifferentResults() {
            Alien blob = new BlobAlien("Goopy", 100, 1.5);
            Alien robot = new RobotAlien("Mechanus", 100, 50.0);

            blob.takeDamage(20);
            robot.takeDamage(20);

            // Blob should take 20 * 1.5 = 30 damage → 70 HP remaining
            // Robot should take 20 * 0.5 = 10 damage → 90 HP remaining
            assertNotEquals(blob.getHealthPoints(), robot.getHealthPoints(),
                    "Different alien types must calculate damage differently");
        }

        @Test
        @DisplayName("BlobAlien damage calculation follows gooiness formula")
        void blobDamageCalculationCorrect() {
            Alien blob = new BlobAlien("Test", 100, 2.0);
            blob.takeDamage(10);

            // Expected: 10 * 2.0 = 20 damage, so 80 HP remaining
            assertEquals(80, blob.getHealthPoints(),
                    "BlobAlien should calculate damage as: damage × gooinessFactor");
        }

        @Test
        @DisplayName("RobotAlien damage calculation follows battery formula")
        void robotDamageCalculationCorrect() {
            Alien robot = new RobotAlien("Test", 100, 75.0);
            robot.takeDamage(20);

            // Expected: 20 * 0.75 = 15 damage, so 85 HP remaining
            assertEquals(85, robot.getHealthPoints(),
                    "RobotAlien should calculate damage as: damage × (battery / 100)");
        }

        @Test
        @DisplayName("getStatus returns different formats for different aliens")
        void getStatusReturnsDifferentFormats() {
            Alien blob = new BlobAlien("Goopy", 100, 1.5);
            Alien robot = new RobotAlien("Mechanus", 100, 75.0);

            String blobStatus = blob.getStatus();
            String robotStatus = robot.getStatus();

            // Status should contain alien type and specific characteristics
            assertTrue(blobStatus.contains("BlobAlien") || blobStatus.contains("Blob"),
                    "BlobAlien status should identify alien type");
            assertTrue(robotStatus.contains("RobotAlien") || robotStatus.contains("Robot"),
                    "RobotAlien status should identify alien type");
            assertTrue(blobStatus.contains("Gooiness") || blobStatus.contains("1.5"),
                    "BlobAlien status should include gooiness information");
            assertTrue(robotStatus.contains("Battery") || robotStatus.contains("75"),
                    "RobotAlien status should include battery information");
        }
    }

    // ========================================================================
    // 4. DYNAMIC BINDING TESTS
    // ========================================================================
    @Nested
    @DisplayName("4. Dynamic Binding Tests")
    class DynamicBindingTests {

        @Test
        @DisplayName("Collection of different aliens calls correct implementations")
        void collectionCallsCorrectImplementations() {
            List<Alien> aliens = new ArrayList<>();
            aliens.add(new BlobAlien("Blob1", 100, 1.5));
            aliens.add(new RobotAlien("Robot1", 100, 50.0));
            aliens.add(new BlobAlien("Blob2", 100, 2.0));

            // Apply same damage to all
            for (Alien alien : aliens) {
                alien.takeDamage(10);
            }

            // Each should have different HP based on their implementation
            assertEquals(85, aliens.get(0).getHealthPoints(), "Blob1: 10 * 1.5 = 15 damage");
            assertEquals(95, aliens.get(1).getHealthPoints(), "Robot1: 10 * 0.5 = 5 damage");
            assertEquals(80, aliens.get(2).getHealthPoints(), "Blob2: 10 * 2.0 = 20 damage");
        }

        @Test
        @DisplayName("Array of aliens demonstrates polymorphic behavior")
        void arrayDemonstratesPolymorphism() {
            Alien[] aliens = {
                new BlobAlien("Goo", 50, 1.0),
                new RobotAlien("Bot", 50, 100.0)
            };

            // Call method on array - should work polymorphically
            for (Alien alien : aliens) {
                alien.takeDamage(25);
            }

            assertEquals(25, aliens[0].getHealthPoints(), "Blob takes full damage at 1.0 gooiness");
            assertEquals(25, aliens[1].getHealthPoints(), "Robot takes full damage at 100% battery");
        }

        @Test
        @DisplayName("Method parameter accepts any Alien implementation")
        void methodParameterAcceptsAnyImplementation() {
            Alien blob = new BlobAlien("Polymorphic", 100, 1.0);
            Alien robot = new RobotAlien("Polymorphic", 100, 100.0);

            // Both should work with the same helper method
            attackAlien(blob, 50);
            attackAlien(robot, 50);

            assertEquals(50, blob.getHealthPoints());
            assertEquals(50, robot.getHealthPoints());
        }

        // Helper method that demonstrates polymorphism
        private void attackAlien(Alien alien, int damage) {
            alien.takeDamage(damage);
        }
    }

    // ========================================================================
    // 5. NO TYPE CASTING REQUIRED
    // ========================================================================
    @Nested
    @DisplayName("5. No Type Casting Required")
    class NoTypeCastingRequired {

        @Test
        @DisplayName("Interface reference works without casting")
        void interfaceReferenceWorksWithoutCasting() {
            Alien alien = new BlobAlien("Test", 100, 1.0);

            // Should be able to call all interface methods without casting
            assertDoesNotThrow(() -> {
                alien.takeDamage(10);
                alien.isDefeated();
                alien.getStatus();
                alien.getName();
                alien.getHealthPoints();
            }, "All interface methods should be callable without casting");
        }

        @Test
        @DisplayName("Process aliens without type checking")
        void processAliensWithoutTypeChecking() {
            List<Alien> aliens = Arrays.asList(
                    new BlobAlien("Goo", 100, 1.5),
                    new RobotAlien("Bot", 100, 75.0)
            );

            // Should be able to process all aliens identically
            assertDoesNotThrow(() -> {
                for (Alien alien : aliens) {
                    alien.takeDamage(20);
                    boolean defeated = alien.isDefeated();
                    String status = alien.getStatus();
                    // No instanceof or casting needed!
                }
            }, "Should process all aliens through interface without type checks");
        }
    }

    // ========================================================================
    // 6. REFLECTION-BASED CHECKS
    // ========================================================================
    @Nested
    @DisplayName("6. Reflection-Based Checks")
    class ReflectionBasedChecks {

        @Test
        @DisplayName("BlobAlien properly implements Alien interface")
        void blobAlienImplementsInterface() {
            Class<?>[] interfaces = BlobAlien.class.getInterfaces();
            boolean implementsAlien = false;
            for (Class<?> iface : interfaces) {
                if (iface.equals(Alien.class)) {
                    implementsAlien = true;
                    break;
                }
            }
            assertTrue(implementsAlien, "BlobAlien must directly implement Alien interface");
        }

        @Test
        @DisplayName("RobotAlien properly implements Alien interface")
        void robotAlienImplementsInterface() {
            Class<?>[] interfaces = RobotAlien.class.getInterfaces();
            boolean implementsAlien = false;
            for (Class<?> iface : interfaces) {
                if (iface.equals(Alien.class)) {
                    implementsAlien = true;
                    break;
                }
            }
            assertTrue(implementsAlien, "RobotAlien must directly implement Alien interface");
        }

        @Test
        @DisplayName("Methods are declared in concrete classes, not just inherited")
        void methodsDeclaredInConcreteClasses() throws NoSuchMethodException {
            // Check BlobAlien declares its own methods
            Method blobTakeDamage = BlobAlien.class.getDeclaredMethod("takeDamage", int.class);
            assertEquals(BlobAlien.class, blobTakeDamage.getDeclaringClass(),
                    "takeDamage must be declared in BlobAlien, not inherited");

            // Check RobotAlien declares its own methods
            Method robotTakeDamage = RobotAlien.class.getDeclaredMethod("takeDamage", int.class);
            assertEquals(RobotAlien.class, robotTakeDamage.getDeclaringClass(),
                    "takeDamage must be declared in RobotAlien, not inherited");
        }

        @Test
        @DisplayName("Interface methods have correct signatures in implementations")
        void interfaceMethodsHaveCorrectSignatures() throws NoSuchMethodException {
            // Check all required interface methods exist with correct signatures
            assertNotNull(BlobAlien.class.getDeclaredMethod("takeDamage", int.class));
            assertNotNull(BlobAlien.class.getDeclaredMethod("isDefeated"));
            assertNotNull(BlobAlien.class.getDeclaredMethod("getStatus"));
            assertNotNull(BlobAlien.class.getDeclaredMethod("getName"));
            assertNotNull(BlobAlien.class.getDeclaredMethod("getHealthPoints"));

            assertNotNull(RobotAlien.class.getDeclaredMethod("takeDamage", int.class));
            assertNotNull(RobotAlien.class.getDeclaredMethod("isDefeated"));
            assertNotNull(RobotAlien.class.getDeclaredMethod("getStatus"));
            assertNotNull(RobotAlien.class.getDeclaredMethod("getName"));
            assertNotNull(RobotAlien.class.getDeclaredMethod("getHealthPoints"));
        }
    }

    // ========================================================================
    // 7. LISKOV SUBSTITUTION PRINCIPLE
    // ========================================================================
    @Nested
    @DisplayName("7. Liskov Substitution Principle")
    class LiskovSubstitutionPrinciple {

        @Test
        @DisplayName("Any Alien can be used where interface is expected")
        void anyAlienCanBeSubstituted() {
            // Create different alien types
            Alien blob = new BlobAlien("Substitutable", 100, 1.0);
            Alien robot = new RobotAlien("Substitutable", 100, 100.0);

            // Both should work identically in this context
            testAlienBehavior(blob);
            testAlienBehavior(robot);
        }

        private void testAlienBehavior(Alien alien) {
            // All operations should work regardless of implementation
            int initialHP = alien.getHealthPoints();
            alien.takeDamage(10);
            assertTrue(alien.getHealthPoints() <= initialHP,
                    "Health should decrease after damage");
            assertNotNull(alien.getName(), "Should have a name");
            assertNotNull(alien.getStatus(), "Should have a status");
        }

        @Test
        @DisplayName("Aliens in collection maintain expected behavior")
        void aliensInCollectionMaintainBehavior() {
            List<Alien> aliens = Arrays.asList(
                    new BlobAlien("A", 100, 1.0),
                    new RobotAlien("B", 100, 100.0),
                    new BlobAlien("C", 100, 1.0),
                    new RobotAlien("D", 100, 100.0)
            );

            // All aliens should behave predictably
            for (Alien alien : aliens) {
                assertFalse(alien.isDefeated(), "New alien should not be defeated");
                alien.takeDamage(50);
                assertEquals(50, alien.getHealthPoints(),
                        "At 1.0/100% should take exact damage");
            }
        }

        @Test
        @DisplayName("Substitution works in defensive system simulation")
        void substitutionWorksInSimulation() {
            DefenseSystem system = new DefenseSystem();

            // Add different alien types
            system.addTarget(new BlobAlien("Invader1", 50, 1.0));
            system.addTarget(new RobotAlien("Invader2", 50, 100.0));

            // System should handle all aliens uniformly
            system.attackAll(25);

            assertTrue(system.getAllTargetsAreProcessed(),
                    "Defense system should process all alien types uniformly");
        }
    }

    // ========================================================================
    // FUNCTIONAL/SPECIFICATION TESTS
    // ========================================================================
    @Nested
    @DisplayName("Functional Tests - BlobAlien")
    class BlobAlienFunctionalTests {

        @Test
        @DisplayName("BlobAlien constructor initializes correctly")
        void constructorInitializesCorrectly() {
            BlobAlien blob = new BlobAlien("Gooey", 100, 1.5);

            assertEquals("Gooey", blob.getName());
            assertEquals(100, blob.getHealthPoints());
            assertEquals(1.5, blob.getGooinessFactor(), 0.001);
        }

        @Test
        @DisplayName("BlobAlien validates gooiness factor range")
        void validatesGooinessFactor() {
            assertThrows(IllegalArgumentException.class, ()
                    -> new BlobAlien("Test", 100, 0.4),
                    "Should reject gooiness below 0.5");

            assertThrows(IllegalArgumentException.class, ()
                    -> new BlobAlien("Test", 100, 2.1),
                    "Should reject gooiness above 2.0");

            assertDoesNotThrow(()
                    -> new BlobAlien("Test", 100, 0.5),
                    "Should accept gooiness of 0.5");

            assertDoesNotThrow(()
                    -> new BlobAlien("Test", 100, 2.0),
                    "Should accept gooiness of 2.0");
        }

        @ParameterizedTest
        @ValueSource(doubles = {0.5, 1.0, 1.5, 2.0})
        @DisplayName("BlobAlien correctly calculates damage with various gooiness factors")
        void calculatesCorrectDamage(double gooinessFactor) {
            BlobAlien blob = new BlobAlien("Test", 100, gooinessFactor);
            blob.takeDamage(20);

            int expectedDamage = (int) Math.round(20 * gooinessFactor);
            int expectedHP = 100 - expectedDamage;

            assertEquals(expectedHP, blob.getHealthPoints(),
                    "Damage should be calculated as: damage × gooinessFactor");
        }

        @Test
        @DisplayName("BlobAlien health cannot go below zero")
        void healthCannotGoBelowZero() {
            BlobAlien blob = new BlobAlien("Test", 50, 1.0);
            blob.takeDamage(100);

            assertEquals(0, blob.getHealthPoints(), "Health should not go below 0");
            assertTrue(blob.isDefeated(), "Alien should be defeated");
        }

        @Test
        @DisplayName("BlobAlien isDefeated works correctly")
        void isDefeatedWorksCorrectly() {
            BlobAlien blob = new BlobAlien("Test", 30, 1.0);

            assertFalse(blob.isDefeated(), "Should not be defeated initially");

            blob.takeDamage(30);
            assertTrue(blob.isDefeated(), "Should be defeated at 0 HP");
        }
    }

    @Nested
    @DisplayName("Functional Tests - RobotAlien")
    class RobotAlienFunctionalTests {

        @Test
        @DisplayName("RobotAlien constructor initializes correctly")
        void constructorInitializesCorrectly() {
            RobotAlien robot = new RobotAlien("Mechanus", 100, 75.0);

            assertEquals("Mechanus", robot.getName());
            assertEquals(100, robot.getHealthPoints());
            assertEquals(75.0, robot.getBatteryPercentage(), 0.001);
        }

        @Test
        @DisplayName("RobotAlien validates battery percentage range")
        void validatesBatteryPercentage() {
            assertThrows(IllegalArgumentException.class, ()
                    -> new RobotAlien("Test", 100, -1.0),
                    "Should reject negative battery");

            assertThrows(IllegalArgumentException.class, ()
                    -> new RobotAlien("Test", 100, 101.0),
                    "Should reject battery over 100");

            assertDoesNotThrow(()
                    -> new RobotAlien("Test", 100, 0.0),
                    "Should accept 0% battery");

            assertDoesNotThrow(()
                    -> new RobotAlien("Test", 100, 100.0),
                    "Should accept 100% battery");
        }

        @ParameterizedTest
        @ValueSource(doubles = {0.0, 25.0, 50.0, 75.0, 100.0})
        @DisplayName("RobotAlien correctly calculates damage with various battery levels")
        void calculatesCorrectDamage(double batteryPercentage) {
            RobotAlien robot = new RobotAlien("Test", 100, batteryPercentage);
            robot.takeDamage(20);

            int expectedDamage = (int) Math.round(20 * (batteryPercentage / 100.0));
            int expectedHP = 100 - expectedDamage;

            assertEquals(expectedHP, robot.getHealthPoints(),
                    "Damage should be calculated as: damage × (battery / 100)");
        }

        @Test
        @DisplayName("RobotAlien health cannot go below zero")
        void healthCannotGoBelowZero() {
            RobotAlien robot = new RobotAlien("Test", 50, 100.0);
            robot.takeDamage(100);

            assertEquals(0, robot.getHealthPoints(), "Health should not go below 0");
            assertTrue(robot.isDefeated(), "Robot should be defeated");
        }

        @Test
        @DisplayName("RobotAlien isDefeated works correctly")
        void isDefeatedWorksCorrectly() {
            RobotAlien robot = new RobotAlien("Test", 30, 100.0);

            assertFalse(robot.isDefeated(), "Should not be defeated initially");

            robot.takeDamage(30);
            assertTrue(robot.isDefeated(), "Should be defeated at 0 HP");
        }
    }

    // ========================================================================
    // HELPER CLASS FOR LISKOV SUBSTITUTION TEST
    // ========================================================================
    /**
     * Simple defense system to test Liskov Substitution Principle. Demonstrates
     * that all Alien implementations can be used interchangeably.
     */
    private static class DefenseSystem {

        private List<Alien> targets = new ArrayList<>();

        public void addTarget(Alien alien) {
            targets.add(alien);
        }

        public void attackAll(int damage) {
            for (Alien alien : targets) {
                alien.takeDamage(damage);
            }
        }

        public boolean getAllTargetsAreProcessed() {
            // All aliens should have taken damage
            for (Alien alien : targets) {
                if (alien.getHealthPoints() == 50) {
                    return false; // No damage was taken
                }
            }
            return !targets.isEmpty();
        }
    }

}
