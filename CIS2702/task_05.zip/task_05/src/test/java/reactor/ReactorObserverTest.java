package reactor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import reactor.core.ReactorCore;
import reactor.core.ReactorObserver;
import reactor.observers.SafetyProtocol;
import reactor.observers.TemperatureDisplay;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A dedicated Mock Observer for precise testing of the notification count.
 * This ensures the pattern is correctly implemented behaviorally.
 */
public class ReactorObserverTest implements ReactorObserver {
    private double receivedTemp = 0.0;
    private int updateCount = 0;

    @Override
    public void update(double temperature) {
        this.receivedTemp = temperature;
        this.updateCount++;
    }

    public double getReceivedTemp() { return receivedTemp; }
    public int getUpdateCount() { return updateCount; }
}

@DisplayName("Reactor Observer Pattern Compliance Tests")
class ReactorMonitoringTest {

    private ReactorCore core;
    private ReactorObserverTest mockObserver1;
    private ReactorObserverTest mockObserver2;
    private final double NEW_TEMP = 450.50;

    @BeforeEach
    void setUp() {
        core = new ReactorCore();
        mockObserver1 = new ReactorObserverTest();
        mockObserver2 = new ReactorObserverTest();
    }

    @Test
    @DisplayName("Test A: ReactorCore must implement attach/detach methods (Structural Check)")
    void testA_subjectHasObserverMethods() {
        Class<ReactorCore> clazz = ReactorCore.class;

        // Check for public attach(ReactorObserver)
        Optional<Method> attachMethod = Arrays.stream(clazz.getMethods())
                .filter(m -> m.getName().equals("attach") && 
                             m.getParameterCount() == 1 && 
                             m.getParameterTypes()[0].equals(ReactorObserver.class))
                .findFirst();
        
        assertTrue(attachMethod.isPresent(), "FAILURE: ReactorCore must have a public attach(ReactorObserver) method.");

        // Check for public detach(ReactorObserver)
        Optional<Method> detachMethod = Arrays.stream(clazz.getMethods())
                .filter(m -> m.getName().equals("detach") && 
                             m.getParameterCount() == 1 && 
                             m.getParameterTypes()[0].equals(ReactorObserver.class))
                .findFirst();
        
        assertTrue(detachMethod.isPresent(), "FAILURE: ReactorCore must have a public detach(ReactorObserver) method.");
    }


    @Test
    @DisplayName("Test B: Notification must be triggered upon temperature change")
    void testB_notificationIsTriggered() {
        core.attach(mockObserver1);
        core.setTemperature(NEW_TEMP);

        assertEquals(1, mockObserver1.getUpdateCount(), "FAILURE: Observer's update() method was not called exactly once.");
        assertEquals(NEW_TEMP, mockObserver1.getReceivedTemp(), 0.001, "FAILURE: Observer received incorrect temperature value.");
    }

    @Test
    @DisplayName("Test C: All multiple attached observers must be notified")
    void testC_multipleObserversAreNotified() {
        core.attach(mockObserver1);
        core.attach(mockObserver2);
        core.setTemperature(NEW_TEMP);

        assertEquals(1, mockObserver1.getUpdateCount(), "FAILURE: The first observer was not notified.");
        assertEquals(1, mockObserver2.getUpdateCount(), "FAILURE: The second observer was not notified.");
    }

    @Test
    @DisplayName("Test D: Detachment must stop future notifications (Concept Enforcement)")
    void testD_observerDetachmentStopsNotifications() {
        core.attach(mockObserver1);
        core.attach(mockObserver2);

        // 1. Initial change: both get notified
        core.setTemperature(350.0); 
        assertEquals(1, mockObserver1.getUpdateCount());
        
        // 2. Detach observer 1
        core.detach(mockObserver1);
        
        // 3. Second change: only observer 2 should be notified
        core.setTemperature(400.0);
        
        // Mock Observer 1 should still have a count of 1 (it was detached)
        assertEquals(1, mockObserver1.getUpdateCount(), 
                     "FAILURE: The detached observer received a subsequent notification.");
        
        // Mock Observer 2 should have a count of 2
        assertEquals(2, mockObserver2.getUpdateCount(), 
                     "FAILURE: The attached observer did not receive the second notification.");
    }
    
    @Test
    @DisplayName("Test E: SafetyProtocol alarm must activate at 500.0K or above (Specification Check)")
    void testE_safetyProtocolAlarmActivation() {
        SafetyProtocol safety = new SafetyProtocol();
        core.attach(safety);

        // Test at the threshold
        core.setTemperature(500.0);
        assertTrue(safety.isAlarmActive(), "FAILURE: Alarm should be active at 500.0K.");

        // Test above the threshold
        core.setTemperature(500.001);
        assertTrue(safety.isAlarmActive(), "FAILURE: Alarm should be active above 500.0K.");
    }

    @Test
    @DisplayName("Test F: SafetyProtocol alarm must deactivate when temperature drops below 500.0K")
    void testF_safetyProtocolAlarmDeactivation() {
        SafetyProtocol safety = new SafetyProtocol();
        core.attach(safety);

        // 1. Activate alarm
        core.setTemperature(550.0);
        assertTrue(safety.isAlarmActive(), "Pre-check failed: Alarm must activate first.");

        // 2. Deactivate alarm
        core.setTemperature(499.99);
        assertFalse(safety.isAlarmActive(), "FAILURE: Alarm should be deactivated below 500.0K.");
    }

    @Test
    @DisplayName("Test G: TemperatureDisplay stores the most recent reading")
    void testG_temperatureDisplayStoresLatestReading() {
        TemperatureDisplay display = new TemperatureDisplay();

        display.update(333.33);
        assertEquals(333.33, display.getLastRecordedTemperature(), 0.0001);

        display.update(470.55);
        assertEquals(470.55, display.getLastRecordedTemperature(), 0.0001);
    }

    @Test
    @DisplayName("Test H: TemperatureDisplay prints a formatted line to stdout")
    void testH_temperatureDisplayPrintsFormattedOutput() {
        TemperatureDisplay display = new TemperatureDisplay();
        java.io.PrintStream originalOut = System.out;
        java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outputStream));

        try {
            display.update(515.346);
        } finally {
            System.setOut(originalOut);
        }

        String printed = outputStream.toString().trim();
        assertTrue(printed.contains("DISPLAY: Core Temperature Updated to 515.35K."),
                () -> "Expected formatted output but was: " + printed);
    }
}
