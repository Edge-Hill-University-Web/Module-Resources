package reactor.observers;

import reactor.core.ReactorObserver;

/**
 * A Concrete Observer: Monitors for critical overheating.
 */
public class SafetyProtocol {
   
}