package reactor.observers;

import reactor.core.ReactorObserver;

/**
 * A Concrete Observer: Displays the current reactor temperature.
 */
public class TemperatureDisplay {
  

}