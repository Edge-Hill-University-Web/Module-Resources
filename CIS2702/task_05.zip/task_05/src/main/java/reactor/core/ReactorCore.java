package reactor.core;

/**
 * The Subject (Observable) in the Observer Pattern.
 * Manages the state (temperature) and notifies attached observers of changes.
 */
public class ReactorCore {
    
}