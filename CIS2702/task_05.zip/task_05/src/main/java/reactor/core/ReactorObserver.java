package reactor.core;

/**
 * The Observer Interface in the Observer Pattern.
 * Defines the contract for all monitoring systems.
 */
public class ReactorObserver {

}